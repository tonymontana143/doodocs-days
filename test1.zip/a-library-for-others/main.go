package main

import (
	"errors"
	"fmt"
	"io"
	"log"
	"os"
)

type CSVParser interface {
	ReadLine(r io.Reader) (*string, error)
	GetNumberOfFields() int
	GetField(n int) (string, error)
}

var (
	ErrQuote      = errors.New("excess or missing \" in quoted-field")
	ErrFieldCount = errors.New("wrong number of fields")
)

type MyParser struct {
	fields     []string
	fieldCount int
}

func (p *MyParser) GetNumberOfFields() int {
	return p.fieldCount
}

func (p *MyParser) ReadLine(r io.Reader) (*string, error) {
	var fields []string
	buffer := make([]byte, 1)
	var currentField []byte
	var line []byte
	inQuote := false

	for {
		_, err := r.Read(buffer)
		if err != nil {
			if err == io.EOF {
				if len(line) > 0 {
					if inQuote {
						return nil, ErrQuote
					}
					if len(currentField) > 0 {
						fields = append(fields, string(currentField))
					}
					p.fields = fields
					p.fieldCount = len(fields)
					lineStr := string(line)
					return &lineStr, nil
				}
				return nil, nil
			}
			return nil, err
		}

		char := buffer[0]
		switch char {
		case '\n':
			if inQuote {
				line = append(line, char)
			} else {
				fields = append(fields, string(currentField))
				p.fields = fields
				p.fieldCount = len(fields)
				lineStr := string(line)
				return &lineStr, nil
			}
		case '\r':
			_, err := r.Read(buffer[:])
			if err == nil && buffer[0] == '\n' {
				if inQuote {
					line = append(line, char)
					line = append(line, buffer[0])
				} else {
					fields = append(fields, string(currentField))
					p.fields = fields
					p.fieldCount = len(fields)
					lineStr := string(line)
					return &lineStr, nil
				}
			} else {
				if inQuote {
					line = append(line, char)
				} else {
					fields = append(fields, string(currentField))
					p.fields = fields
					p.fieldCount = len(fields)
					lineStr := string(line)
					return &lineStr, nil
				}
			}
		case '"':
			if inQuote {
				currentField = append(currentField, char)

			}
			inQuote = !inQuote
		case ',':
			if inQuote {
				currentField = append(currentField, char)
			} else {
				fields = append(fields, string(currentField))
				currentField = nil
			}
		default:
			currentField = append(currentField, char)
		}
		line = append(line, char)
	}
}

func (p *MyParser) GetField(n int) (string, error) {
	if n < 0 || n >= p.fieldCount {
		return "", ErrFieldCount
	}
	field := p.fields[n]
	// Remove surrounding quotes if present
	if len(field) > 1 && field[0] == '"' && field[len(field)-1] == '"' {
		return field[1 : len(field)-1], nil
	}
	return field, nil
}

func main() {
	file, err := os.Open("example.csv")
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	var csvParser CSVParser = &MyParser{}
	for i := 0; i < 3; i++ {
		line, err := csvParser.ReadLine(file)
		if err != nil {
			fmt.Println("Error:", err)
			break
		}
		if line == nil {
			break
		}
		fmt.Println(*line)
	}

	numFields := csvParser.GetNumberOfFields()
	fmt.Println("Number of fields:", numFields)
	for i := 0; i < numFields; i++ {
		field, err := csvParser.GetField(i)
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Printf("Field %d: %s\n", i+1, field)
		}
	}
}
